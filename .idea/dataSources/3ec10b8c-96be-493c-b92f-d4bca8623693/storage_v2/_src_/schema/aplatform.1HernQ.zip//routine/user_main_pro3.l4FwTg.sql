CREATE PROCEDURE user_main_pro3(OUT v_count INT)
  BEGIN  
  SET v_count=9;  
END;

