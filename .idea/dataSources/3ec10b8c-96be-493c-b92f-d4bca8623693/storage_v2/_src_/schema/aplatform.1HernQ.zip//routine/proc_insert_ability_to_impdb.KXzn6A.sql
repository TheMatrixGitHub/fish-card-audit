CREATE PROCEDURE proc_insert_ability_to_impdb(IN n TEXT, IN code_status VARCHAR(1))
  BEGIN 
    -- FLAG_XX 是否需要导出XX表，0:导出；非0:不导出
	DECLARE FLAG_AOP_ABILITY_BASEINFO	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_EXTINFO	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_PROTOCOL	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ST_QUOTA_RULE	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_DIRECTORY	INT DEFAULT 0;		
	DECLARE FLAG_AOP_OPERATOR_TASK	INT DEFAULT 0;	
	DECLARE FLAG_AOP_ATTACH	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_LABEL_RELATION	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_LABEL	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_GRAY	INT DEFAULT 0;	
	-- errmsg
	DECLARE ERR_MSG	TEXT DEFAULT '';
	DECLARE I_ERROR	TEXT DEFAULT '';
	DECLARE CODE CHAR(5) DEFAULT '00000';
	DECLARE msg TEXT;
	
	DECLARE num_code_status VARCHAR(1);
	
	-- errmsg
	 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
	    BEGIN
	     GET DIAGNOSTICS CONDITION 1
		CODE = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
		SET I_ERROR = CONCAT('Execuate failed, error = ',CODE,', message = ',msg);
	    END;
	    
	SET @@sql_mode='NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';  
																																				
	IF	FLAG_AOP_ABILITY_BASEINFO=0 THEN																																								
					INSERT INTO AOP_ABILITY_BASEINFO		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND a.ABILITY_STATUS='3';																								
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_BASEINFO");SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_EXTINFO=0 THEN																																								
					INSERT INTO AOP_ABILITY_EXTINFO		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_EXTINFO	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																																																												
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_EXTINFO");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_PROTOCOL=0 THEN																																								
					INSERT INTO AOP_ABILITY_PROTOCOL		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_PROTOCOL	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																																																															
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_PROTOCOL");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ST_QUOTA_RULE=0 THEN																																								
					INSERT INTO AOP_ST_QUOTA_RULE		SELECT	a.*		FROM	TEMP_TABLES_AOP_ST_QUOTA_RULE	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n	AND	STATUS='U'	AND b.ABILITY_STATUS='3' AND a.STATUS='U' ORDER	BY	CREATE_DATE	DESC	LIMIT	1;																
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ST_QUOTA_RULE");SET I_ERROR='';
			END IF;
		 END IF;				 
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_DIRECTORY=0 THEN																																								
					INSERT INTO AOP_ABILITY_DIRECTORY		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_DIRECTORY	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	b.ability_code=n	AND	a.NODE_ID=b.ability_id	AND	NODE_TYPE=1 AND b.ABILITY_STATUS='3';																																																												
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_DIRECTORY");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_OPERATOR_TASK=0 THEN																																								
					INSERT INTO AOP_OPERATOR_TASK		SELECT	a.*		FROM	TEMP_TABLES_AOP_OPERATOR_TASK	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	b.ability_code=n	AND	a.BUSI_ID=b.ability_id	AND b.ABILITY_STATUS='3' ORDER	BY	CREATE_TIME	DESC	LIMIT	1;																		
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_OPERATOR_TASK");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ATTACH=0 THEN																																								
					INSERT INTO AOP_ATTACH		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b,TEMP_TABLES_AOP_ATTACH	AS	a	WHERE	a.file_id=b.ABILITY_LOGO	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ATTACH");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_LABEL_RELATION=0 THEN																																								
					INSERT INTO AOP_ABILITY_LABEL_RELATION		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_LABEL_RELATION	AS	a,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_code=b.ability_code	AND	a.ability_code=n	AND b.ABILITY_STATUS='3' GROUP	BY	a.ID	ORDER	BY	a.label_code;																		
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_LABEL_RELATION");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_LABEL=0 THEN																																								
					INSERT INTO AOP_ABILITY_LABEL		SELECT	a.*		FROM	TEMP_TABLES_AOP_ABILITY_LABEL	AS	a,TEMP_TABLES_AOP_ABILITY_LABEL_RELATION	AS	b,TEMP_TABLES_AOP_ABILITY_BASEINFO	AS	c	WHERE	b.ability_code=c.ability_code	AND	c.ability_code=n	AND	a.label_code=b.label_code	AND c.ABILITY_STATUS='3' GROUP	BY	a.id	ORDER	BY	b.label_code;														
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_LABEL");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																										
	IF	FLAG_AOP_ABILITY_GRAY=0 THEN	 																																							
					INSERT INTO AOP_ABILITY_GRAY SELECT a.* FROM TEMP_TABLES_AOP_ABILITY_GRAY AS a,TEMP_TABLES_AOP_ABILITY_BASEINFO AS b WHERE a.ability_code=b.ability_code AND b.ability_code=n AND b.ABILITY_STATUS='3'  GROUP BY a.gray_id;																																							
	-- test error			 
	-- INSERT INTO AOP_ABILITY_GRAY SELECT a.* FROM TEMP_TABLES_AOP_ABILITY_ORA AS a,TEMP_TABLES_AOP_ABILITY_BASEINFO AS b WHERE a.ability_code=b.ability_code AND b.ability_code=n AND b.ABILITY_STATUS='3'  GROUP BY a.gray_id;																																							
				 
		IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR," in table AOP_ABILITY_GRAY");SET I_ERROR='';
			END IF;
		 END IF;
	END IF;		
	UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG=ERR_MSG WHERE ABILITY_CODE=n;
END;

