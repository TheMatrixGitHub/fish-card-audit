CREATE PROCEDURE proc_loop_insert_datas()
  BEGIN
	SET @@sql_mode='NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'; 	
	-- 调用存储过程，新建临时表
	CALL proc_test_imptemp_tables;
	-- CALL proc_drop_create_imptemp_tables;
	
	UPDATE TEMP_TABLES_ABILITY_CODE SET  INPUT_LOG='',OUTPUT_LOG='';	
	UPDATE TEMP_TABLES_CENTER_SERVICE_CODE SET  INPUT_LOG='',OUTPUT_LOG='';	
	
	-- 把所有需要check的service（包括中心和编排类）都归总到同一个表中
	INSERT INTO TEMP_TABLES_CENTER_SERVICE_CODE (`SERVICE_CODE`,`CODE_STATUS`) SELECT SERVICE_CODE,STATUS FROM TEMP_TABLES_AOP_SRV_SERVICE_INFO WHERE SERVICE_TYPE='3'; 
    
	CALL proc_loop_check_insert_datas('ability');
	CALL proc_loop_check_insert_datas('service');	
END;

