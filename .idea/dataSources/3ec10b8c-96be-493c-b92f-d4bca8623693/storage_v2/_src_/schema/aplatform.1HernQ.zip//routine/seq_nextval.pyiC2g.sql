CREATE FUNCTION seq_nextval(seq_name CHAR(30))
  RETURNS BIGINT
  begin
 UPDATE sys_sequences SET LAST_NUMBER= case last_number when 0 THEN last_insert_id(START_BY) else last_insert_id(LAST_NUMBER+INCREMENT_BY) end WHERE SEQUENCE_NAME=seq_name;
 RETURN last_insert_id();
end;

