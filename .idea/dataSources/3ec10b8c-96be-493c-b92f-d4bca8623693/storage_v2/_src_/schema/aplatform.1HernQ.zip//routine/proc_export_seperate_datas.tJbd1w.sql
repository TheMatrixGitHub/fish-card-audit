CREATE PROCEDURE proc_export_seperate_datas(IN code_flag VARCHAR(255))
  BEGIN
	DECLARE duplicate_key INT DEFAULT FALSE;
	DECLARE v_abil_code VARCHAR(255); 
	DECLARE v_srv_code VARCHAR(255);
	DECLARE v_add_id DECIMAL(12,0) ; 
	DECLARE v_status VARCHAR(1) ; 
	DECLARE v_code_list TEXT  DEFAULT '';
	DECLARE v_split_code_list TEXT;
	DECLARE save_inc_number DECIMAL(12,0) DEFAULT 0;
	DECLARE ability_inc_number_now DECIMAL(12,0) DEFAULT 0;
    -- 遍历数据结束标志
    DECLARE done INT DEFAULT FALSE;
    -- ability游标
    DECLARE ab_cursor CURSOR FOR SELECT ABILITY_CODE,ADD_ID,CODE_STATUS FROM TEMP_TABLES_ABILITY_CODE;
    -- 封装类服务游标
    DECLARE srv_cursor CURSOR FOR SELECT SERVICE_CODE,ADD_ID,CODE_STATUS FROM TEMP_TABLES_CENTER_SERVICE_CODE;
    -- 将结束标志绑定到游标
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    -- DECLARE CONTINUE HANDLER FOR 1062 SET duplicate_key=TRUE;
    
    SET @ability_flag='ability';
    SET @service_flag='service';
    
    -- 获取上次保存的id增加值，并更新当前id增加值
  --  SET save_inc_number=(SELECT INC_NUMBER_LAST_IMP FROM TEMP_TABLES_SAVE_INC_NUMBER LIMIT 1);
  --  UPDATE TEMP_TABLES_ABILITY_CODE SET ADD_ID=ADD_ID+save_inc_number;
  --  UPDATE TEMP_TABLES_CENTER_SERVICE_CODE SET ADD_ID=ADD_ID+save_inc_number;
  --  SET ability_inc_number_now=(SELECT ADD_ID FROM TEMP_TABLES_ABILITY_CODE LIMIT 1);
    -- 获取当前ability的id增加值，并保存回TEMP_TABLES_SAVE_INC_NUMBER表
  --  UPDATE TEMP_TABLES_SAVE_INC_NUMBER SET INC_NUMBER_LAST_IMP=ability_inc_number_now;   
    	
    IF code_flag=@ability_flag THEN
    -- 打开游标
    OPEN  ab_cursor;      
    -- 遍历
    read_loop: LOOP
            -- 取值 取多个字段
            FETCH  ab_cursor INTO v_abil_code,v_add_id,v_status;           
            IF done THEN
                LEAVE read_loop;
             END IF;
             -- SET v_code_list=CONCAT(v_code_list,",","'",v_abil_code,"'");
       -- SET v_split_code_list=(SELECT RIGHT(v_code_list,LENGTH(v_code_list)-1));##截取字符串
       -- SET v_code_list=CONCAT("'",v_abil_code,"'");
       SET @n=v_abil_code;
       	IF v_status='U' THEN
        -- 调用存储过程
	CALL proc_insert_ability(@n,v_status);  
	END IF;
            END LOOP;    
    CLOSE ab_cursor;  
         SET @increase_id=(SELECT ADD_ID FROM TEMP_TABLES_ABILITY_CODE LIMIT 1);   	
	 CALL proc_update_ability(@n,@increase_id);
  ELSEIF code_flag=@service_flag THEN
    -- 打开游标
    OPEN  srv_cursor;      
    -- 遍历
    read_loop: LOOP
            -- 取值 取多个字段
            FETCH  srv_cursor INTO v_srv_code,v_add_id,v_status;            
            IF done THEN
                LEAVE read_loop;
             END IF;
             -- SET v_code_list=CONCAT(v_code_list,",","'",v_srv_code,"'");
             -- SET v_code_list=CONCAT("'",v_srv_code,"'");
	     SET @n=v_srv_code; 
	     IF v_status='U' THEN
             -- 调用存储过程
	    CALL proc_insert_service(@n,v_status,'service',''); 
	    END IF; 
            END LOOP;    
    CLOSE srv_cursor; 
       -- SET v_split_code_list=(SELECT RIGHT(v_code_list,LENGTH(v_code_list)-1));##截取字符串
       -- SET @n=v_split_code_list;
        -- 调用存储过程
	-- CALL proc_insert_service(@n,@increase_id);	
	SET @increase_id=(SELECT ADD_ID FROM TEMP_TABLES_ABILITY_CODE LIMIT 1);  	
	CALL proc_update_service(@n,@increase_id,'service');
   ELSE
    SELECT SERVICE_CODE,ADD_ID,CODE_STATUS FROM TEMP_TABLES_CENTER_SERVICE_CODE;
 END IF;
    CALL proc_rollback_sql;
END;

