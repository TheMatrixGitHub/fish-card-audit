CREATE PROCEDURE proc_insert_service(IN n              TEXT, IN code_status VARCHAR(1), IN ability_code VARCHAR(255),
                                     IN ability_errmsg TEXT)
  BEGIN
        -- FLAG_XX 是否需要导出XX表，0:导出；非0:不导出
	DECLARE FLAG_AOP_SRV_SERVICE_INFO	INT DEFAULT 0;		
	DECLARE FLAG_AOP_SRV_SERVICE_EXT_INFO	INT DEFAULT 0;		
	DECLARE FLAG_AOP_SRV_WF_PACK	INT DEFAULT 0;		
	DECLARE FLAG_VM_TEMPLATE	INT DEFAULT 0;		
	DECLARE FLAG_VM_TEMPLATE_VERSION	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ATTACH	INT DEFAULT 0;		
	DECLARE FLAG_AOP_SRV_SERVICE_ROUTER	INT DEFAULT 0;		
	DECLARE FLAG_AOP_SRV_ROUTER_PATH	INT DEFAULT 0;		
	DECLARE FLAG_AOP_SRV_APP_NODE	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_SERVICE_REF	INT DEFAULT 0;		
	DECLARE FLAG_AOP_OPERATOR_TASK	INT DEFAULT 0;		
	DECLARE FLAG_AOP_SRV_SERVICE_PARAM	INT DEFAULT 0;		
	DECLARE FLAG_AOP_PARAM_CONF	INT DEFAULT 0;		
	DECLARE FLAG_AOP_PARAM_MAPPING	INT DEFAULT 0;		
	DECLARE FLAG_AOP_PARAM_PASS_MAPPING	INT DEFAULT 0;	
	-- errmsg
	DECLARE ERR_MSG	TEXT DEFAULT '';
	DECLARE I_ERROR	TEXT DEFAULT '';
	DECLARE CODE CHAR(5) DEFAULT '00000';
	DECLARE msg TEXT;
	
	DECLARE duplicate_key INT DEFAULT FALSE;
	
	-- errmsg
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
	    BEGIN
	     GET DIAGNOSTICS CONDITION 1
		CODE = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
		SET I_ERROR = CONCAT('Execuate failed, error = ',CODE,', message = ',msg);
	    END;
	DECLARE CONTINUE HANDLER FOR 1062 SET duplicate_key=TRUE;
	-- UPDATE  temp_tables_center_service_code SET INPUT_LOG='duplicate keys (1) found' WHERE service_code=n;
	SET	FLAG_AOP_SRV_SERVICE_INFO=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_SERVICE_INFO%');
	SET	FLAG_AOP_SRV_SERVICE_EXT_INFO=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_SERVICE_EXT_INFO%');
	SET	FLAG_AOP_SRV_WF_PACK=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_WF_PACK%');
	SET	FLAG_VM_TEMPLATE=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%VM_TEMPLATE%');
	SET	FLAG_VM_TEMPLATE_VERSION=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%VM_TEMPLATE_VERSION%');
	SET	FLAG_AOP_ATTACH=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_ATTACH%');
	SET	FLAG_AOP_SRV_SERVICE_ROUTER=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_SERVICE_ROUTER%');
	SET	FLAG_AOP_SRV_ROUTER_PATH=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_ROUTER_PATH%');
	SET	FLAG_AOP_SRV_APP_NODE=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_APP_NODE%');
	SET	FLAG_AOP_ABILITY_SERVICE_REF=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_SERVICE_REF%');
	SET	FLAG_AOP_OPERATOR_TASK=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_OPERATOR_TASK%');
	SET	FLAG_AOP_SRV_SERVICE_PARAM=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_SRV_SERVICE_PARAM%');
	SET	FLAG_AOP_PARAM_CONF=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_PARAM_CONF%');
	SET	FLAG_AOP_PARAM_MAPPING=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_PARAM_MAPPING%');
	SET	FLAG_AOP_PARAM_PASS_MAPPING=(SELECT COUNT(*) FROM 	TEMP_TABLES_CENTER_SERVICE_CODE	WHERE SERVICE_CODE=n	AND INVALID_TABLES LIKE '%AOP_PARAM_PASS_MAPPING%');
        -- SET     ERR_MSG=(SELECT INPUT_LOG FROM TEMP_TABLES_CENTER_SERVICE_CODE WHERE SERVICE_CODE=n);
	SET @@sql_mode='NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	
	  IF ability_code!='service' THEN	
		SET ERR_MSG=ability_errmsg;	
	  END IF;
	  
	-- 编排类和中心服务共有
	IF	FLAG_AOP_SRV_SERVICE_INFO=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_SERVICE_INFO	SELECT	a.*		FROM	AOP_SRV_SERVICE_INFO	AS	a	WHERE	a.service_code=n	AND	a.STATUS='U'	GROUP	BY	a.service_id;																								
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_SERVICE_INFO	SELECT	a.*		FROM	AOP_SRV_SERVICE_INFO	AS	a	WHERE	a.service_code=n	AND	a.STATUS='U'	GROUP	BY	a.service_id;																								
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
		   IF I_ERROR!='' THEN 
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;																																							
	END IF;																																										
																																											
	IF	FLAG_AOP_SRV_SERVICE_EXT_INFO=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_SERVICE_EXT_INFO	SELECT	a.*		FROM	AOP_SRV_SERVICE_EXT_INFO	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	b.STATUS='U'	AND	a.service_id=b.service_id	GROUP	BY	a.ext_id;																				
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_SERVICE_EXT_INFO	SELECT	a.*		FROM	AOP_SRV_SERVICE_EXT_INFO	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	b.STATUS='U'	AND	a.service_id=b.service_id	GROUP	BY	a.ext_id;																				
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;	
	IF	FLAG_AOP_ATTACH=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ATTACH	SELECT	a.*		FROM	AOP_ATTACH	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.file_id=b.ext_a	AND	a.STATUS='U'	AND	b.STATUS='U'	GROUP	BY	a.file_id;																		
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ATTACH	SELECT	a.*		FROM	AOP_ATTACH	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.file_id=b.ext_a	AND	a.STATUS='U'	AND	b.STATUS='U'	GROUP	BY	a.file_id;																		
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;	
	
	IF	FLAG_AOP_OPERATOR_TASK=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_OPERATOR_TASK	SELECT	a.*		FROM	AOP_OPERATOR_TASK	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.BUSI_ID=b.service_id	AND	b.STATUS='U'	ORDER	BY	a.CREATE_TIME	DESC	LIMIT	1;																	
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_OPERATOR_TASK	SELECT	a.*		FROM	AOP_OPERATOR_TASK	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.BUSI_ID=b.service_id	AND	b.STATUS='U'	ORDER	BY	a.CREATE_TIME	DESC	LIMIT	1;																	
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;		
	
	-- 编排类服务有
  IF ability_code!='service' THEN	
	IF	FLAG_AOP_ABILITY_SERVICE_REF=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_SERVICE_REF	SELECT	a.*		FROM	AOP_ABILITY_SERVICE_REF	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_ABILITY_BASEINFO	AS	c	WHERE	b.service_code=n	AND	a.service_id=b.service_id	AND	a.ability_id=c.ability_id	AND	b.STATUS='U'	GROUP	BY	a.ABILITY_ID;																
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_SERVICE_REF	SELECT	a.*		FROM	AOP_ABILITY_SERVICE_REF	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_ABILITY_BASEINFO	AS	c	WHERE	b.service_code=n	AND	a.service_id=b.service_id	AND	a.ability_id=c.ability_id	AND	b.STATUS='U'	GROUP	BY	a.ABILITY_ID;																
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;				
																																											
	IF	FLAG_AOP_SRV_WF_PACK=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_WF_PACK	SELECT	a.*		FROM	AOP_SRV_WF_PACK	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.service_id=b.service_id	AND	a.STATUS='U'	AND	b.STATUS='U'	GROUP	BY	a.service_pack_id;																		
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_WF_PACK	SELECT	a.*		FROM	AOP_SRV_WF_PACK	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.service_id=b.service_id	AND	a.STATUS='U'	AND	b.STATUS='U'	GROUP	BY	a.service_pack_id;																		
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
																																											
	IF	FLAG_VM_TEMPLATE=0 THEN																																								
					INSERT INTO TEMP_TABLES_VM_TEMPLATE	SELECT	a.*		FROM	VM_TEMPLATE	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.TEMPLATE_TAG	=	c.WF_TEMPLATE	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.template_tag;												
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_VM_TEMPLATE	SELECT	a.*		FROM	VM_TEMPLATE	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.TEMPLATE_TAG	=	c.WF_TEMPLATE	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.template_tag;												
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 
	END IF;																																										
																																											
	IF	FLAG_VM_TEMPLATE_VERSION=0 THEN																																								
					INSERT INTO TEMP_TABLES_VM_TEMPLATE_VERSION	SELECT	a.*		FROM	VM_TEMPLATE_VERSION	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.TEMPLATE_TAG	=	c.WF_TEMPLATE	AND	b.STATUS='U'	AND	c.STATUS='U'	ORDER	BY	a.TEMPLATE_VERSION_ID	DESC	LIMIT	1;									
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_VM_TEMPLATE_VERSION	SELECT	a.*		FROM	VM_TEMPLATE_VERSION	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.TEMPLATE_TAG	=	c.WF_TEMPLATE	AND	b.STATUS='U'	AND	c.STATUS='U'	ORDER	BY	a.TEMPLATE_VERSION_ID	DESC	LIMIT	1;									
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
	IF	FLAG_AOP_PARAM_CONF=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_PARAM_CONF	SELECT	a.*		FROM	AOP_PARAM_CONF	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.rel_obj	=	c.WF_TEMPLATE	AND	a.STATE='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.id;										
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_PARAM_CONF	SELECT	a.*		FROM	AOP_PARAM_CONF	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.rel_obj	=	c.WF_TEMPLATE	AND	a.STATE='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.id;										
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
																																											
	IF	FLAG_AOP_PARAM_MAPPING=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_PARAM_MAPPING	SELECT	a.*		FROM	AOP_PARAM_MAPPING	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.WF_TEMPLATE	=	c.WF_TEMPLATE	AND	a.STATE='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.id;										
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_PARAM_MAPPING	SELECT	a.*		FROM	AOP_PARAM_MAPPING	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.WF_TEMPLATE	=	c.WF_TEMPLATE	AND	a.STATE='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.id;										
					SET duplicate_key=FALSE;																																						
				 END IF;	
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
    -- test error		 
    --	 INSERT INTO TEMP_TABLES_AOP_SRV_APP_NODE	SELECT	a.*		FROM	AOP_SRV	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_SERVICE_ROUTER	AS	c,AOP_SRV_ROUTER_PATH	AS	d,AOP_SRV_APP_NODE	AS	e	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	c.route_path=d.path_code	AND	a.app_node_code=d.app_nodes	AND	a.STATUS='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	AND	d.STATUS='U'	AND	d.APP_NODES=e.APP_NODE_CODE	GROUP	BY	a.APP_NODE_ID;					 																																									 																																						
	END IF;																																										
																																										
	IF	FLAG_AOP_PARAM_PASS_MAPPING=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_PARAM_PASS_MAPPING	SELECT	a.*		FROM	AOP_PARAM_PASS_MAPPING	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.WF_TEMPLATE	=	c.WF_TEMPLATE	AND	a.STATE='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.id;										
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_PARAM_PASS_MAPPING	SELECT	a.*		FROM	AOP_PARAM_PASS_MAPPING	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_WF_PACK	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.WF_TEMPLATE	=	c.WF_TEMPLATE	AND	a.STATE='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.id;										
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;	
  END IF;	
	-- 中心服务有
  IF ability_code='service' THEN	
	IF	FLAG_AOP_SRV_SERVICE_ROUTER=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_SERVICE_ROUTER	SELECT	a.*		FROM	AOP_SRV_SERVICE_ROUTER	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.service_id=b.service_id	AND	a.STATUS='U'	AND	b.STATUS='U'	GROUP	BY	a.ROUTE_ID;																		
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_SERVICE_ROUTER	SELECT	a.*		FROM	AOP_SRV_SERVICE_ROUTER	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	b.service_code=n	AND	a.service_id=b.service_id	AND	a.STATUS='U'	AND	b.STATUS='U'	GROUP	BY	a.ROUTE_ID;																		
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
																																											
	IF	FLAG_AOP_SRV_ROUTER_PATH=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_ROUTER_PATH	SELECT	a.*		FROM	AOP_SRV_ROUTER_PATH	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_SERVICE_ROUTER	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.path_code=c.route_path	AND	a.STATUS='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.ID;												
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_ROUTER_PATH	SELECT	a.*		FROM	AOP_SRV_ROUTER_PATH	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_SERVICE_ROUTER	AS	c	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	a.path_code=c.route_path	AND	a.STATUS='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	GROUP	BY	a.ID;												
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
			
																																								
	 IF	FLAG_AOP_SRV_APP_NODE=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_APP_NODE	SELECT	a.*		FROM	AOP_SRV_APP_NODE	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_SERVICE_ROUTER	AS	c,AOP_SRV_ROUTER_PATH	AS	d,AOP_SRV_APP_NODE	AS	e	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	c.route_path=d.path_code	AND	a.app_node_code=d.app_nodes	AND	a.STATUS='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	AND	d.STATUS='U'	AND	d.APP_NODES=e.APP_NODE_CODE	GROUP	BY	a.APP_NODE_ID;		
				-- IF ERR_MSG='' or  ERR_MSG=';' THEN
				--   SET ERR_MSG=I_ERROR;SET I_ERROR='';
				-- ELSE
				-- SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
				-- END IF;				
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_APP_NODE	SELECT	a.*		FROM	AOP_SRV_APP_NODE	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_SERVICE_ROUTER	AS	c,AOP_SRV_ROUTER_PATH	AS	d,AOP_SRV_APP_NODE	AS	e	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	c.route_path=d.path_code	AND	a.app_node_code=d.app_nodes	AND	a.STATUS='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	AND	d.STATUS='U'	AND	d.APP_NODES=e.APP_NODE_CODE	GROUP	BY	a.APP_NODE_ID;		
					SET duplicate_key=FALSE;																																						
				 END IF;
	  -- test error
	  -- INSERT INTO TEMP_TABLES_AOP_SRV_APP_NODE	SELECT	a.*		FROM	AOP_SRV_APP_NODE22	AS	a,AOP_SRV_SERVICE_INFO	AS	b,AOP_SRV_SERVICE_ROUTER	AS	c,AOP_SRV_ROUTER_PATH	AS	d,AOP_SRV_APP_NODE	AS	e	WHERE	b.service_code=n	AND	b.service_id=c.service_id	AND	c.route_path=d.path_code	AND	a.app_node_code=d.app_nodes	AND	a.STATUS='U'	AND	b.STATUS='U'	AND	c.STATUS='U'	AND	d.STATUS='U'	AND	d.APP_NODES=e.APP_NODE_CODE	GROUP	BY	a.APP_NODE_ID;	
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;																																							
	 END IF;																																										
																																																																																																																																																																					
																																											
	IF	FLAG_AOP_SRV_SERVICE_PARAM=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_SRV_SERVICE_PARAM	SELECT	a.*		FROM	AOP_SRV_SERVICE_PARAM	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	a.service_code=b.service_code	AND	a.service_code=n	AND	a.state='U'	AND	b.STATUS='U'	GROUP	BY	a.PARAM_ID	DESC;																	
				 IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_SRV_SERVICE_PARAM	SELECT	a.*		FROM	AOP_SRV_SERVICE_PARAM	AS	a,AOP_SRV_SERVICE_INFO	AS	b	WHERE	a.service_code=b.service_code	AND	a.service_code=n	AND	a.state='U'	AND	b.STATUS='U'	GROUP	BY	a.PARAM_ID	DESC;																	
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
  END IF;																																											
    -- UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG=ERR_MSG WHERE ABILITY_CODE=ability_code;
	 IF ability_code='service' THEN
		UPDATE  TEMP_TABLES_CENTER_SERVICE_CODE SET INPUT_LOG=ERR_MSG WHERE SERVICE_CODE=n;	
		-- UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG="111" WHERE ABILITY_CODE=ability_code;
	 ELSE
		UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG=ERR_MSG WHERE ABILITY_CODE=ability_code;
		-- UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG="222" WHERE ABILITY_CODE=ability_code;
	 END IF;																																		
END;

