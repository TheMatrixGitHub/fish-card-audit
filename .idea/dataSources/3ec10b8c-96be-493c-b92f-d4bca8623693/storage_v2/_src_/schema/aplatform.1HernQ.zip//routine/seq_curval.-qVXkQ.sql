CREATE FUNCTION seq_curval(seq_name CHAR(30))
  RETURNS INT
  begin
 DECLARE cur  int;
 select LAST_NUMBER into cur from sys_sequences WHERE SEQUENCE_NAME=seq_name;
 RETURN  cur;
end;

