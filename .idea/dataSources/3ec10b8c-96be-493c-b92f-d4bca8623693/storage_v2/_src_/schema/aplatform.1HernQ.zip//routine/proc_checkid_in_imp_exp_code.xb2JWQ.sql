CREATE PROCEDURE proc_checkid_in_imp_exp_code(IN CODE        VARCHAR(255), IN code_flag VARCHAR(255),
                                              IN code_status VARCHAR(10), OUT idconflict_in_impdb INT)
  BEGIN
	-- errmsg
	DECLARE ERR_MSG	TEXT DEFAULT '';
	DECLARE I_ERROR	TEXT DEFAULT '';
	DECLARE msg TEXT;
	
	DECLARE v_maxid_impdb DECIMAL(12,0) DEFAULT 0 ;
	DECLARE v_minid_expdb DECIMAL(12,0) DEFAULT 0 ; 	
	SET @@sql_mode='NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'; 
	SET idconflict_in_impdb=0;
    IF code_flag='ability' AND code_status='U' THEN
			SET v_maxid_impdb=(SELECT MAX(ABILITY_ID)	 FROM	AOP_ABILITY_BASEINFO);														
			SET v_minid_expdb=(SELECT MIN(ABILITY_ID)	 FROM	TEMP_TABLES_AOP_ABILITY_BASEINFO);													
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ABILITY_ID在表AOP_ABILITY_BASEINFO的最大值应该小于TEMP_TABLES_AOP_ABILITY_BASEINFO的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ABILITY_ID)	 FROM	AOP_ABILITY_EXTINFO);														
			SET v_minid_expdb=(SELECT MIN(ABILITY_ID)	 FROM	TEMP_TABLES_AOP_ABILITY_EXTINFO);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ABILITY_ID在表AOP_ABILITY_EXTINFO的最大值应该小于TEMP_TABLES_AOP_ABILITY_EXTINFO的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_ABILITY_PROTOCOL);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_ABILITY_PROTOCOL);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_ABILITY_PROTOCOL的最大值应该小于TEMP_TABLES_AOP_ABILITY_PROTOCOL的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(QUOTA_RULE_ID)	 FROM	AOP_ST_QUOTA_RULE);														
			SET v_minid_expdb=(SELECT MIN(QUOTA_RULE_ID)	 FROM	TEMP_TABLES_AOP_ST_QUOTA_RULE);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='QUOTA_RULE_ID在表AOP_ST_QUOTA_RULE的最大值应该小于TEMP_TABLES_AOP_ST_QUOTA_RULE的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_ABILITY_DIRECTORY);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_ABILITY_DIRECTORY);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_ABILITY_DIRECTORY的最大值应该小于TEMP_TABLES_AOP_ABILITY_DIRECTORY的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(TID)	 FROM	AOP_OPERATOR_TASK);														
			SET v_minid_expdb=(SELECT MIN(TID)	 FROM	TEMP_TABLES_AOP_OPERATOR_TASK);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='TID在表AOP_OPERATOR_TASK的最大值应该小于TEMP_TABLES_AOP_OPERATOR_TASK的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(FILE_ID)	 FROM	AOP_ATTACH);														
			SET v_minid_expdb=(SELECT MIN(FILE_ID)	 FROM	TEMP_TABLES_AOP_ATTACH);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='FILE_ID在表AOP_ATTACH的最大值应该小于TEMP_TABLES_AOP_ATTACH的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_ABILITY_LABEL_RELATION);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_ABILITY_LABEL_RELATION);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_ABILITY_LABEL_RELATION的最大值应该小于TEMP_TABLES_AOP_ABILITY_LABEL_RELATION的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_ABILITY_LABEL);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_ABILITY_LABEL);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_ABILITY_LABEL的最大值应该小于TEMP_TABLES_AOP_ABILITY_LABEL的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(GRAY_ID)	 FROM	AOP_ABILITY_GRAY);														
			SET v_minid_expdb=(SELECT MIN(GRAY_ID)	 FROM	TEMP_TABLES_AOP_ABILITY_GRAY);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='GRAY_ID在表AOP_ABILITY_GRAY的最大值应该小于TEMP_TABLES_AOP_ABILITY_GRAY的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;
				 
			IF ERR_MSG!='' THEN
			    SET idconflict_in_impdb=1;			
				UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG=ERR_MSG WHERE ABILITY_CODE=CODE;
			END IF;
	ELSE 
			SET v_maxid_impdb=(SELECT MAX(SERVICE_ID)	 FROM	AOP_SRV_SERVICE_INFO);														
			SET v_minid_expdb=(SELECT MIN(SERVICE_ID)	 FROM	TEMP_TABLES_AOP_SRV_SERVICE_INFO);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='SERVICE_ID在表AOP_SRV_SERVICE_INFO的最大值应该小于TEMP_TABLES_AOP_SRV_SERVICE_INFO的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(EXT_ID)	 FROM	AOP_SRV_SERVICE_EXT_INFO);														
			SET v_minid_expdb=(SELECT MIN(EXT_ID)	 FROM	TEMP_TABLES_AOP_SRV_SERVICE_EXT_INFO);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='EXT_ID在表AOP_SRV_SERVICE_EXT_INFO的最大值应该小于TEMP_TABLES_AOP_SRV_SERVICE_EXT_INFO的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(SERVICE_PACK_ID)	 FROM	AOP_SRV_WF_PACK);														
			SET v_minid_expdb=(SELECT MIN(SERVICE_PACK_ID)	 FROM	TEMP_TABLES_AOP_SRV_WF_PACK);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='SERVICE_PACK_ID在表AOP_SRV_WF_PACK的最大值应该小于TEMP_TABLES_AOP_SRV_WF_PACK的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(TEMPLATE_VERSION_ID)	 FROM	VM_TEMPLATE_VERSION);														
			SET v_minid_expdb=(SELECT MIN(TEMPLATE_VERSION_ID)	 FROM	TEMP_TABLES_VM_TEMPLATE_VERSION);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='TEMPLATE_VERSION_ID在表VM_TEMPLATE_VERSION的最大值应该小于TEMP_TABLES_VM_TEMPLATE_VERSION的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(FILE_ID)	 FROM	AOP_ATTACH);														
			SET v_minid_expdb=(SELECT MIN(FILE_ID)	 FROM	TEMP_TABLES_AOP_ATTACH);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='FILE_ID在表AOP_ATTACH的最大值应该小于TEMP_TABLES_AOP_ATTACH的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ROUTE_ID)	 FROM	AOP_SRV_SERVICE_ROUTER);														
			SET v_minid_expdb=(SELECT MIN(ROUTE_ID)	 FROM	TEMP_TABLES_AOP_SRV_SERVICE_ROUTER);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ROUTE_ID在表AOP_SRV_SERVICE_ROUTER的最大值应该小于TEMP_TABLES_AOP_SRV_SERVICE_ROUTER的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_SRV_ROUTER_PATH);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_SRV_ROUTER_PATH);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_SRV_ROUTER_PATH的最大值应该小于TEMP_TABLES_AOP_SRV_ROUTER_PATH的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(APP_NODE_ID)	 FROM	AOP_SRV_APP_NODE);														
			SET v_minid_expdb=(SELECT MIN(APP_NODE_ID)	 FROM	TEMP_TABLES_AOP_SRV_APP_NODE);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='APP_NODE_ID在表AOP_SRV_APP_NODE的最大值应该小于TEMP_TABLES_AOP_SRV_APP_NODE的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ABILITY_ID)	 FROM	AOP_ABILITY_SERVICE_REF);														
			SET v_minid_expdb=(SELECT MIN(ABILITY_ID)	 FROM	TEMP_TABLES_AOP_ABILITY_SERVICE_REF);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ABILITY_ID在表AOP_ABILITY_SERVICE_REF的最大值应该小于TEMP_TABLES_AOP_ABILITY_SERVICE_REF的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(TID)	 FROM	AOP_OPERATOR_TASK);														
			SET v_minid_expdb=(SELECT MIN(TID)	 FROM	TEMP_TABLES_AOP_OPERATOR_TASK);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='TID在表AOP_OPERATOR_TASK的最大值应该小于TEMP_TABLES_AOP_OPERATOR_TASK的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(PARAM_ID)	 FROM	AOP_SRV_SERVICE_PARAM);														
			SET v_minid_expdb=(SELECT MIN(PARAM_ID)	 FROM	TEMP_TABLES_AOP_SRV_SERVICE_PARAM);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='PARAM_ID在表AOP_SRV_SERVICE_PARAM的最大值应该小于TEMP_TABLES_AOP_SRV_SERVICE_PARAM的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_PARAM_CONF);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_PARAM_CONF);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_PARAM_CONF的最大值应该小于TEMP_TABLES_AOP_PARAM_CONF的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_PARAM_MAPPING);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_PARAM_MAPPING);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_PARAM_MAPPING的最大值应该小于TEMP_TABLES_AOP_PARAM_MAPPING的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;																		
																				
			SET v_maxid_impdb=(SELECT MAX(ID)	 FROM	AOP_PARAM_PASS_MAPPING);														
			SET v_minid_expdb=(SELECT MIN(ID)	 FROM	TEMP_TABLES_AOP_PARAM_PASS_MAPPING);														
			IF v_maxid_impdb>=v_minid_expdb THEN																		
				SET I_ERROR='ID在表AOP_PARAM_PASS_MAPPING的最大值应该小于TEMP_TABLES_AOP_PARAM_PASS_MAPPING的最小值，否则可能引起主键冲突';																		
			END IF;
				 IF ERR_MSG='' OR  ERR_MSG=';' THEN
					SET ERR_MSG=I_ERROR;SET I_ERROR='';
				 ELSE
					IF I_ERROR!='' THEN
					SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
					END IF;
				 END IF;
			IF ERR_MSG!='' THEN
			    SET idconflict_in_impdb=1;
				UPDATE  TEMP_TABLES_CENTER_SERVICE_CODE SET INPUT_LOG=ERR_MSG WHERE SERVICE_CODE=CODE;	
			END IF;
	END IF;	
END;

