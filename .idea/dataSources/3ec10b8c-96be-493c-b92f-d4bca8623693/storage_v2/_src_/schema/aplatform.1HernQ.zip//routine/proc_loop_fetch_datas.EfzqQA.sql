CREATE PROCEDURE proc_loop_fetch_datas()
  BEGIN
	DECLARE save_inc_number DECIMAL(12,0) DEFAULT 0;
	DECLARE ability_inc_number_now DECIMAL(12,0) DEFAULT 0;
	SET @@sql_mode='NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'; 
	
	-- 调用存储过程，新建临时表
	CALL proc_drop_create_temp_tables;
        -- 获取上次保存的id增加值，并更新当前id增加值
	SET save_inc_number=(SELECT INC_NUMBER_LAST_IMP FROM TEMP_TABLES_SAVE_INC_NUMBER LIMIT 1);
	UPDATE TEMP_TABLES_ABILITY_CODE SET ADD_ID=ADD_ID+save_inc_number;
	UPDATE TEMP_TABLES_CENTER_SERVICE_CODE SET ADD_ID=ADD_ID+save_inc_number;
	SET ability_inc_number_now=(SELECT ADD_ID FROM TEMP_TABLES_ABILITY_CODE LIMIT 1);
    
	-- 获取当前ability的id增加值，并保存回TEMP_TABLES_SAVE_INC_NUMBER表
	UPDATE TEMP_TABLES_SAVE_INC_NUMBER SET INC_NUMBER_LAST_IMP=ability_inc_number_now; 
    
	CALL proc_export_seperate_datas('ability');
	CALL proc_export_seperate_datas('service');
	
END;

