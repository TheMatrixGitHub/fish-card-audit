CREATE PROCEDURE user_main_pro2(IN  CODE              VARCHAR(255), IN code_flag VARCHAR(255),
                                IN  code_status       VARCHAR(10), OUT sum_code_in_impdb INT)
  BEGIN  
	-- errmsg
	DECLARE ERR_MSG	TEXT DEFAULT '';
	DECLARE I_ERROR	TEXT DEFAULT '';
	DECLARE CODE CHAR(5) DEFAULT '00000';
	DECLARE msg TEXT;
    IF code_flag='ability' AND code_status='U' THEN
		SELECT  COUNT(*)     INTO sum_code_in_impdb        FROM    AOP_ABILITY_BASEINFO   WHERE   ability_code=code;		
			 IF sum_code_in_impdb!=0 THEN
				SET ERR_MSG='This ability already exist in import db';
				 UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG=ERR_MSG WHERE ABILITY_CODE=v_abil_code;
			 END IF;
		end if;		
END;

