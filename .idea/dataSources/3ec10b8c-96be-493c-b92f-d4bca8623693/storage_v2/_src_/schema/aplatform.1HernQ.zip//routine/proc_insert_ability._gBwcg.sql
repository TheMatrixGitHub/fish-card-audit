CREATE PROCEDURE proc_insert_ability(IN n TEXT, IN code_status VARCHAR(1))
  BEGIN 
        -- FLAG_XX 是否需要导出XX表，0:导出；非0:不导出
	DECLARE FLAG_AOP_ABILITY_BASEINFO	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_EXTINFO	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_PROTOCOL	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ST_QUOTA_RULE	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_DIRECTORY	INT DEFAULT 0;		
	DECLARE FLAG_AOP_OPERATOR_TASK	INT DEFAULT 0;	
	DECLARE FLAG_AOP_ATTACH	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_LABEL_RELATION	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_LABEL	INT DEFAULT 0;		
	DECLARE FLAG_AOP_ABILITY_GRAY	INT DEFAULT 0;	
	-- errmsg
	DECLARE ERR_MSG	TEXT DEFAULT '';
	DECLARE I_ERROR	TEXT DEFAULT '';
	DECLARE CODE CHAR(5) DEFAULT '00000';
	DECLARE msg TEXT;
	
	DECLARE duplicate_key INT DEFAULT FALSE;
	DECLARE num_code_status VARCHAR(1);
	
	-- errmsg
	 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
	    BEGIN
	     GET DIAGNOSTICS CONDITION 1
		CODE = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
		SET I_ERROR = CONCAT('Execuate failed, error = ',CODE,', message = ',msg);
	    END;
	    
	DECLARE CONTINUE HANDLER FOR 1062 SET duplicate_key=TRUE;
	SET	FLAG_AOP_ABILITY_BASEINFO=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_BASEINFO%');
	SET	FLAG_AOP_ABILITY_EXTINFO=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_EXTINFO%');
	SET	FLAG_AOP_ABILITY_PROTOCOL=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_PROTOCOL%');
	SET	FLAG_AOP_ST_QUOTA_RULE=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ST_QUOTA_RULE%');
	SET	FLAG_AOP_ABILITY_DIRECTORY=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_DIRECTORY%');
	SET	FLAG_AOP_OPERATOR_TASK=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_OPERATOR_TASK%');
	SET	FLAG_AOP_ATTACH=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ATTACH%');
	SET	FLAG_AOP_ABILITY_LABEL_RELATION=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_LABEL_RELATION%');
	SET	FLAG_AOP_ABILITY_LABEL=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_LABEL%');
	SET	FLAG_AOP_ABILITY_GRAY=(SELECT COUNT(*) FROM 	TEMP_TABLES_ABILITY_CODE	WHERE ABILITY_CODE=n	AND INVALID_TABLES LIKE '%AOP_ABILITY_GRAY%');
	SET @@sql_mode='NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';  
																																				
	IF	FLAG_AOP_ABILITY_BASEINFO=0 THEN
																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_BASEINFO		SELECT	a.*		FROM	AOP_ABILITY_BASEINFO	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND a.ABILITY_STATUS='3';																								
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_BASEINFO		SELECT	a.*		FROM	AOP_ABILITY_BASEINFO	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND a.ABILITY_STATUS='3';																								
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 																																							
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_EXTINFO=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_EXTINFO		SELECT	a.*		FROM	AOP_ABILITY_EXTINFO	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_EXTINFO		SELECT	a.*		FROM	AOP_ABILITY_EXTINFO	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_PROTOCOL=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_PROTOCOL		SELECT	a.*		FROM	AOP_ABILITY_PROTOCOL	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_PROTOCOL		SELECT	a.*		FROM	AOP_ABILITY_PROTOCOL	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ST_QUOTA_RULE=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ST_QUOTA_RULE		SELECT	a.*		FROM	AOP_ST_QUOTA_RULE	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n	AND	STATUS='U'	AND b.ABILITY_STATUS='3' AND a.STATUS='U' ORDER	BY	CREATE_DATE	DESC	LIMIT	1;																
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ST_QUOTA_RULE		SELECT	a.*		FROM	AOP_ST_QUOTA_RULE	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_id=b.ability_id	AND	b.ability_code=n	AND	STATUS='U'	AND b.ABILITY_STATUS='3' AND a.STATUS='U' ORDER	BY	CREATE_DATE	DESC	LIMIT	1;																
					SET duplicate_key=FALSE;																																						
				 END IF;
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;				 
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_DIRECTORY=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_DIRECTORY		SELECT	a.*		FROM	AOP_ABILITY_DIRECTORY	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	b.ability_code=n	AND	a.NODE_ID=b.ability_id	AND	NODE_TYPE=1 AND b.ABILITY_STATUS='3';																						
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_DIRECTORY		SELECT	a.*		FROM	AOP_ABILITY_DIRECTORY	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	b.ability_code=n	AND	a.NODE_ID=b.ability_id	AND	NODE_TYPE=1 AND b.ABILITY_STATUS='3';																						
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_OPERATOR_TASK=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_OPERATOR_TASK		SELECT	a.*		FROM	AOP_OPERATOR_TASK	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	b.ability_code=n	AND	a.BUSI_ID=b.ability_id	AND b.ABILITY_STATUS='3' ORDER	BY	CREATE_TIME	DESC	LIMIT	1;																		
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_OPERATOR_TASK		SELECT	a.*		FROM	AOP_OPERATOR_TASK	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	b.ability_code=n	AND	a.BUSI_ID=b.ability_id	AND b.ABILITY_STATUS='3' ORDER	BY	CREATE_TIME	DESC	LIMIT	1;																		
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ATTACH=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ATTACH		SELECT	a.*		FROM	AOP_ABILITY_BASEINFO	AS	b,AOP_ATTACH	AS	a	WHERE	a.file_id=b.ABILITY_LOGO	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ATTACH		SELECT	a.*		FROM	AOP_ABILITY_BASEINFO	AS	b,AOP_ATTACH	AS	a	WHERE	a.file_id=b.ABILITY_LOGO	AND	b.ability_code=n AND b.ABILITY_STATUS='3';																								
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_LABEL_RELATION=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_LABEL_RELATION		SELECT	a.*		FROM	AOP_ABILITY_LABEL_RELATION	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_code=b.ability_code	AND	a.ability_code=n	AND b.ABILITY_STATUS='3' GROUP	BY	a.ID	ORDER	BY	a.label_code;																		
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_LABEL_RELATION		SELECT	a.*		FROM	AOP_ABILITY_LABEL_RELATION	AS	a,AOP_ABILITY_BASEINFO	AS	b	WHERE	a.ability_code=b.ability_code	AND	a.ability_code=n	AND b.ABILITY_STATUS='3' GROUP	BY	a.ID	ORDER	BY	a.label_code;																		
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																											
	IF	FLAG_AOP_ABILITY_LABEL=0 THEN																																								
					INSERT INTO TEMP_TABLES_AOP_ABILITY_LABEL		SELECT	a.*		FROM	AOP_ABILITY_LABEL	AS	a,AOP_ABILITY_LABEL_RELATION	AS	b,AOP_ABILITY_BASEINFO	AS	c	WHERE	b.ability_code=c.ability_code	AND	c.ability_code=n	AND	a.label_code=b.label_code	AND c.ABILITY_STATUS='3' GROUP	BY	a.id	ORDER	BY	b.label_code;														
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_LABEL		SELECT	a.*		FROM	AOP_ABILITY_LABEL	AS	a,AOP_ABILITY_LABEL_RELATION	AS	b,AOP_ABILITY_BASEINFO	AS	c	WHERE	b.ability_code=c.ability_code	AND	c.ability_code=n	AND	a.label_code=b.label_code	AND c.ABILITY_STATUS='3' GROUP	BY	a.id	ORDER	BY	b.label_code;														
					SET duplicate_key=FALSE;																																						
				 END IF;																																							
		 IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;																																										
																																										
	IF	FLAG_AOP_ABILITY_GRAY=0 THEN	 																																							
					INSERT INTO TEMP_TABLES_AOP_ABILITY_GRAY SELECT a.* FROM AOP_ABILITY_GRAY AS a,AOP_ABILITY_BASEINFO AS b WHERE a.ability_code=b.ability_code AND b.ability_code=n AND b.ABILITY_STATUS='3'  GROUP BY a.gray_id;																																							
				IF duplicate_key THEN																																							
					REPLACE INTO TEMP_TABLES_AOP_ABILITY_GRAY SELECT a.* FROM AOP_ABILITY_GRAY AS a,AOP_ABILITY_BASEINFO AS b WHERE a.ability_code=b.ability_code AND b.ability_code=n AND b.ABILITY_STATUS='3'  GROUP BY a.gray_id;																																						
					SET duplicate_key=FALSE;																																						
				 END IF;
	-- test error			 
	-- INSERT INTO TEMP_TABLES_AOP_ABILITY_GRAY SELECT a.* FROM AOP_ABILITY_ORA AS a,AOP_ABILITY_BASEINFO AS b WHERE a.ability_code=b.ability_code AND b.ability_code=n AND b.ABILITY_STATUS='3'  GROUP BY a.gray_id;																																							
				 
		IF ERR_MSG='' OR  ERR_MSG=';' THEN
			SET ERR_MSG=I_ERROR;SET I_ERROR='';
		 ELSE
			IF I_ERROR!='' THEN
			SET ERR_MSG=CONCAT(ERR_MSG,";",I_ERROR);SET I_ERROR='';
			END IF;
		 END IF;
	END IF;	
	
	UPDATE  TEMP_TABLES_ABILITY_CODE SET INPUT_LOG=ERR_MSG WHERE ABILITY_CODE=n;
	SET @pkg_service_code=(SELECT a.service_code FROM AOP_SRV_SERVICE_INFO AS a,AOP_ABILITY_SERVICE_REF AS b,AOP_ABILITY_BASEINFO AS c WHERE c.ability_code=n AND b.ability_id=c.ability_id AND a.service_id=b.service_id GROUP BY a.service_id);
	IF @pkg_service_code IS NOT NULL THEN
	  CALL proc_insert_service(@pkg_service_code,code_status,n,ERR_MSG);
	END IF;
END;

