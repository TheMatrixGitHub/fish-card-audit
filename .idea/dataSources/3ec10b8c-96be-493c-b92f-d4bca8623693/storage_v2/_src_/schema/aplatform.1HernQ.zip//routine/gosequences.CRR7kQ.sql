CREATE PROCEDURE gosequences()
  BEGIN
declare c0 varchar(50); 
declare c1 long ; 
declare c2 long ;    
declare done int;
DECLARE rs_cursor CURSOR FOR SELECT t.SEQUENCE_NAME,t.START_VALUE,t.INCREMENT_VALUE from cfg_id_generator t;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;


open rs_cursor; 
cursor_loop:loop
   FETCH rs_cursor into c0, c1, c2; -- 取数据

   if done=1 then
    leave cursor_loop;
   end if;

INSERT IGNORE into sys_sequences  (SEQUENCE_NAME,START_BY,INCREMENT_BY,LAST_NUMBER) values (c0,IFNULL(c1,1000),IFNULL(c2,1),IFNULL(c1,1001)); 
end loop cursor_loop;
close rs_cursor;
    END;

