CREATE PROCEDURE proc_loop_check_insert_datas(IN code_flag VARCHAR(255))
  BEGIN
	DECLARE duplicate_key INT DEFAULT FALSE;
	DECLARE v_abil_code VARCHAR(255); 
	DECLARE v_srv_code VARCHAR(255);
	DECLARE v_add_id DECIMAL(12,0) ; 
	DECLARE v_status VARCHAR(1) ; 
	DECLARE v_code_list TEXT  DEFAULT '';
	DECLARE v_split_code_list TEXT;
	DECLARE save_inc_number DECIMAL(12,0) DEFAULT 0;
	DECLARE ability_inc_number_now DECIMAL(12,0) DEFAULT 0;
	-- errmsg
	DECLARE ERR_MSG	TEXT DEFAULT '';
    -- 遍历数据结束标志
    DECLARE done INT DEFAULT FALSE;
    -- ability游标
    DECLARE ab_cursor CURSOR FOR SELECT ABILITY_CODE,CODE_STATUS FROM TEMP_TABLES_ABILITY_CODE;
    -- 封装类服务游标
    DECLARE srv_cursor CURSOR FOR SELECT SERVICE_CODE,CODE_STATUS FROM TEMP_TABLES_CENTER_SERVICE_CODE;
    -- 将结束标志绑定到游标
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    SET @ability_flag='ability';
    SET @service_flag='service';
 
    IF code_flag=@ability_flag THEN
    -- 打开游标
    OPEN  ab_cursor;      
    -- 遍历
    read_loop: LOOP
            -- 取值 取多个字段
            FETCH  ab_cursor INTO v_abil_code,v_status;           
            IF done THEN
                LEAVE read_loop;
             END IF;
				SET @n=v_abil_code;
				SET @v_sum_code_in_impdb=0;
				SET @v_idconflict_in_impdb=0;
				-- 插入数据前检测导入库中是否已有该code
				 CALL proc_checkcode_exist_by_code(v_abil_code,'ability',v_status,@v_sum_code_in_impdb);  
				 IF @v_sum_code_in_impdb=1 AND v_status='U' THEN
				    CALL proc_checkid_in_imp_exp_code (v_abil_code,'ability',v_status,@v_idconflict_in_impdb);
				  -- IF @v_idconflict_in_impdb=1 THEN
				  --	CALL proc_insert_ability_to_impdb(v_abil_code,v_status);
				  -- END IF;
				 END IF;
	
            END LOOP;    
    CLOSE ab_cursor; 
    SET @increase_id=(SELECT ADD_ID FROM TEMP_TABLES_ABILITY_CODE LIMIT 1); 
    -- 更新sequence 
    -- CALL proc_update_ability_sequence(@n,@increase_id);
  ELSEIF code_flag=@service_flag THEN
    -- 打开游标
    OPEN  srv_cursor;      
    -- 遍历
    read_loop: LOOP
            -- 取值 取多个字段
            FETCH  srv_cursor INTO v_srv_code,v_status;            
            IF done THEN
                LEAVE read_loop;
            END IF;
			
			-- 调用存储过程
				SET @n=v_srv_code;
				SET @v_sum_code_in_impdb=0;
				SET @v_idconflict_in_impdb=0;
			-- 插入数据前检测导入库中是否已有该code
				CALL proc_checkcode_exist_by_code(v_srv_code,'service',v_status,@v_sum_code_in_impdb); 
				IF @v_sum_code_in_impdb=1 AND v_status='U' THEN
				     CALL proc_checkid_in_imp_exp_code (v_srv_code,'service',v_status,@v_idconflict_in_impdb);
					IF @v_idconflict_in_impdb=1 THEN
						CALL proc_insert_service_to_impdb(v_srv_code,v_status);	
					END IF;
				END IF;
            END LOOP;    
    CLOSE srv_cursor; 
        SET @increase_id=(SELECT ADD_ID FROM TEMP_TABLES_ABILITY_CODE LIMIT 1);  
    -- 更新sequence
    --	CALL proc_update_srv_sequence(@n,@increase_id);
   ELSE
    SELECT SERVICE_CODE,ADD_ID,CODE_STATUS FROM TEMP_TABLES_CENTER_SERVICE_CODE;
 END IF;
END;

